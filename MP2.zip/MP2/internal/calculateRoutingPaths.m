function [outputArg1,outputArg2] = calculateRoutingPaths(inputArg1,inputArg2)
    %CALCULATEROUTINGPATHS returns the 
    %   Detailed explanation goes here
    outputArg1 = inputArg1;
    outputArg2 = inputArg2;
end