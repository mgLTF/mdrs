TODO:

 - Divide the work. Last time Miguel only had Sim2 done, at the last class it looks he was finishing the Sim4.

In Task 1 we need to use Sim2 (Sim with added bit error rate, ber) and do 
some simulations, represent the results in barcharts and justify the 
results. Easy.

In Task 2 we need to use Sim3 and develop a variant called Sim3A where a 
bit error rate, ber, is introduced, just like Sim2, do some simulations, 
plot the bar plots and draw relevant conclusions.

In Task 3 we need to use both Sim3 and Sim4, do some simulations and 
discuss the results, after that develop a Sim4A that discards data packets
if the queue is p % filled, simulate and discuss the results

As I started with writing and formating the Word document I can start with
Task 1. You can start with Task 2, Task 3 it's probably best to do 
together?! 


